package comunicacao.pacotes;

public class Pacote {
	public Cabecalho cabecalho;
	public String conteudo;
}
