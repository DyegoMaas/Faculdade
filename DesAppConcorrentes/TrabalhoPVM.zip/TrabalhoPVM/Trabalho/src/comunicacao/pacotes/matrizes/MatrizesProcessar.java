package comunicacao.pacotes.matrizes;

public class MatrizesProcessar {
	public double[][] matriz1;
	public double[][] matriz2;
}
