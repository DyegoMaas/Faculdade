package comunicacao.pacotes.matrizes;

public class MatrizesReposta{
	public double[][] matriz;
}
