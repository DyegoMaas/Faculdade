package comunicacao.pacotes;

public class Cabecalho {
	public String nomeArquivo;
}
